package aui.lab.repositories;

import org.springframework.stereotype.Repository;

@Repository
public class ItemRepository {
}
